function dydx = ODE3b(x,y)
    dydx = (1+4*x)*sqrt(y);
end